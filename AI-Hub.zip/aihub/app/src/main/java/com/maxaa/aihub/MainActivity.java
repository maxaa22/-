package com.maxaa.aihub;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * AI Хаб — one app with a switcher for Claude, ChatGPT, Gemini, BrainMax
 * (and any other AI site you add). Every AI lives in its own WebView that
 * stays alive in the background, so chats and logins are kept while you
 * switch. No API keys: you sign in with your normal accounts.
 */
public class MainActivity extends Activity {

    private static final String PREFS = "aihub";
    private static final String KEY_SERVICES = "services";
    private static final String KEY_ACTIVE = "active";
    private static final int REQ_FILE = 101;
    private static final int REQ_PERM = 102;

    static class Service {
        String name, url; int color;
        Service(String n, String u, int c) { name = n; url = u; color = c; }
    }

    private final List<Service> services = new ArrayList<>();
    private final List<WebView> webViews = new ArrayList<>();
    private int active = 0;

    private LinearLayout pillRow;
    private FrameLayout container;
    private ProgressBar progress;

    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingPermission;

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        loadServices();
        active = Math.min(prefs().getInt(KEY_ACTIVE, 0), services.size() - 1);
        buildUi();
        rebuildAll();
        handleShare(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleShare(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush(); // keep logins after the app is killed
        prefs().edit().putInt(KEY_ACTIVE, active).apply();
    }

    @Override
    public void onBackPressed() {
        WebView wv = current();
        if (wv != null && wv.canGoBack()) wv.goBack();
        else moveTaskToBack(true); // don't destroy chats, just go to the background
    }

    // ---------------------------------------------------------------- UI

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0E0F14"));

        // top bar: scrollable pills + menu button
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(4), dp(8));

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        pillRow = new LinearLayout(this);
        pillRow.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(pillRow);
        bar.addView(scroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView menu = new TextView(this);
        menu.setText("⋯");
        menu.setTextColor(Color.WHITE);
        menu.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        menu.setGravity(Gravity.CENTER);
        menu.setBackground(glass(Color.parseColor("#22FFFFFF"), 0));
        menu.setOnClickListener(v -> showMainMenu());
        bar.addView(menu, new LinearLayout.LayoutParams(dp(44), dp(40)));

        root.addView(bar);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        container = new FrameLayout(this);
        root.addView(container, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);
    }

    private void renderPills() {
        pillRow.removeAllViews();
        for (int i = 0; i < services.size(); i++) {
            final int idx = i;
            Service s = services.get(i);
            boolean on = i == active;

            TextView pill = new TextView(this);
            pill.setText(s.name);
            pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            pill.setTypeface(Typeface.DEFAULT, on ? Typeface.BOLD : Typeface.NORMAL);
            pill.setTextColor(on ? Color.WHITE : Color.parseColor("#B8BCCB"));
            pill.setPadding(dp(16), dp(9), dp(16), dp(9));
            pill.setBackground(on
                    ? glass((s.color & 0x00FFFFFF) | 0x55000000, s.color)
                    : glass(Color.parseColor("#16FFFFFF"), 0));
            pill.setOnClickListener(v -> select(idx));
            pill.setOnLongClickListener(v -> { showServiceMenu(idx); return true; });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(6);
            pillRow.addView(pill, lp);
        }
    }

    private GradientDrawable glass(int fill, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(20));
        d.setColor(fill);
        d.setStroke(dp(1), stroke != 0 ? stroke : Color.parseColor("#26FFFFFF"));
        return d;
    }

    // ---------------------------------------------------------------- tabs

    private void rebuildAll() {
        for (WebView w : webViews) if (w != null) { container.removeView(w); w.destroy(); }
        webViews.clear();
        for (int i = 0; i < services.size(); i++) webViews.add(null); // created lazily
        if (active >= services.size()) active = 0;
        select(active);
    }

    private void select(int idx) {
        if (services.isEmpty()) { renderPills(); return; }
        active = idx;
        if (webViews.get(idx) == null) {
            WebView wv = makeWebView();
            webViews.set(idx, wv);
            container.addView(wv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            wv.loadUrl(services.get(idx).url);
        }
        for (int i = 0; i < webViews.size(); i++) {
            WebView w = webViews.get(i);
            if (w != null) w.setVisibility(i == idx ? View.VISIBLE : View.GONE);
        }
        WebView cur = webViews.get(idx);
        int p = cur.getProgress();
        progress.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
        progress.setProgress(p);
        renderPills();
    }

    private WebView current() {
        return (active < webViews.size()) ? webViews.get(active) : null;
    }

    private WebView makeWebView() {
        WebView wv = new WebView(this);
        wv.setBackgroundColor(Color.parseColor("#0E0F14"));

        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(false); // popups open in the same tab
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        // Look like normal Chrome — Google blocks sign-in from "wv" user agents.
        s.setUserAgentString(WebSettings.getDefaultUserAgent(this)
                .replace("; wv", "")
                .replaceAll("Version/\\d+\\.\\d+ ", ""));

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(wv, true);

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("http") || scheme.equals("https")) return false;
                openExternal(u.toString());
                return true;
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                if (view != current()) return;
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = params.createIntent();
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(i, "Вибери файл"), REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }
        });

        wv.setDownloadListener((url, ua, cd, mime, len) -> openExternal(url));
        return wv;
    }

    private void openExternal(String url) {
        try {
            Intent i = url.startsWith("intent:")
                    ? Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    : new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(i);
        } catch (Exception e) {
            toast("Не вдалося відкрити посилання");
        }
    }

    // ---------------------------------------------------------------- mic / camera / files

    private void handleWebPermission(PermissionRequest request) {
        List<String> need = new ArrayList<>();
        for (String r : request.getResources()) {
            if (r.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.RECORD_AUDIO);
            if (r.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.CAMERA);
        }
        if (need.isEmpty()) { request.grant(request.getResources()); return; }
        pendingPermission = request;
        requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERM || pendingPermission == null) return;
        boolean ok = true;
        for (int r : results) ok &= r == PackageManager.PERMISSION_GRANTED;
        if (ok) pendingPermission.grant(pendingPermission.getResources());
        else pendingPermission.deny();
        pendingPermission = null;
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code != REQ_FILE || fileCallback == null) return;
        Uri[] uris = null;
        if (result == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                uris = new Uri[clip.getItemCount()];
                for (int i = 0; i < clip.getItemCount(); i++) uris[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                uris = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(uris);
        fileCallback = null;
    }

    // ---------------------------------------------------------------- share into the app

    private void handleShare(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text == null || text.isEmpty()) return;
        ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText("AI Хаб", text));
        toast("Текст скопійовано — встав його в чат");
    }

    // ---------------------------------------------------------------- menus

    private void showMainMenu() {
        String[] items = {"Оновити сторінку", "На головну цього ШІ", "Додати ШІ", "Скинути список до стандартного"};
        new AlertDialog.Builder(this)
                .setItems(items, (d, which) -> {
                    WebView wv = current();
                    switch (which) {
                        case 0: if (wv != null) wv.reload(); break;
                        case 1: if (wv != null) wv.loadUrl(services.get(active).url); break;
                        case 2: editService(-1); break;
                        case 3: confirm("Скинути список ШІ до стандартного?", () -> {
                            services.clear(); services.addAll(defaults()); saveServices();
                            active = 0; rebuildAll();
                        }); break;
                    }
                }).show();
    }

    private void showServiceMenu(int idx) {
        Service s = services.get(idx);
        String[] items = {"Оновити", "Змінити назву / адресу", "Видалити", "← Посунути вліво"};
        new AlertDialog.Builder(this)
                .setTitle(s.name)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0: select(idx); current().reload(); break;
                        case 1: editService(idx); break;
                        case 2: confirm("Видалити " + s.name + "?", () -> {
                            WebView w = webViews.remove(idx);
                            if (w != null) { container.removeView(w); w.destroy(); }
                            services.remove(idx); saveServices();
                            if (active >= services.size()) active = Math.max(0, services.size() - 1);
                            select(active);
                        }); break;
                        case 3: if (idx > 0) {
                            services.add(idx - 1, services.remove(idx));
                            webViews.add(idx - 1, webViews.remove(idx));
                            if (active == idx) active = idx - 1;
                            else if (active == idx - 1) active = idx;
                            saveServices(); renderPills();
                        } break;
                    }
                }).show();
    }

    private void editService(int idx) {
        boolean isNew = idx < 0;
        Service s = isNew ? null : services.get(idx);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        EditText name = new EditText(this);
        name.setHint("Назва (напр. Perplexity)");
        name.setSingleLine();
        if (s != null) name.setText(s.name);
        box.addView(name);

        EditText url = new EditText(this);
        url.setHint("https://…");
        url.setSingleLine();
        url.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(s != null ? s.url : "https://");
        box.addView(url);

        new AlertDialog.Builder(this)
                .setTitle(isNew ? "Додати ШІ" : "Змінити " + s.name)
                .setView(box)
                .setPositiveButton("Зберегти", (d, w) -> {
                    String n = name.getText().toString().trim();
                    String u = url.getText().toString().trim();
                    if (n.isEmpty() || u.length() < 9) { toast("Заповни назву та адресу"); return; }
                    if (!u.startsWith("http")) u = "https://" + u;
                    if (isNew) {
                        int[] palette = {0xFFF2B84B, 0xFF4FD1C5, 0xFFFF6B9A, 0xFF7ED957};
                        services.add(new Service(n, u, palette[services.size() % palette.length]));
                        webViews.add(null);
                        saveServices();
                        select(services.size() - 1);
                    } else {
                        boolean urlChanged = !u.equals(s.url);
                        s.name = n; s.url = u; saveServices();
                        if (urlChanged && webViews.get(idx) != null) webViews.get(idx).loadUrl(u);
                        renderPills();
                    }
                })
                .setNegativeButton("Скасувати", null)
                .show();
    }

    private void confirm(String msg, Runnable yes) {
        new AlertDialog.Builder(this).setMessage(msg)
                .setPositiveButton("Так", (d, w) -> yes.run())
                .setNegativeButton("Ні", null).show();
    }

    // ---------------------------------------------------------------- storage

    private static List<Service> defaults() {
        List<Service> l = new ArrayList<>();
        l.add(new Service("Claude", "https://claude.ai/new", 0xFFD97757));
        l.add(new Service("ChatGPT", "https://chatgpt.com/", 0xFF10A37F));
        l.add(new Service("Gemini", "https://gemini.google.com/app", 0xFF4C8DF6));
        l.add(new Service("BrainMax", "https://app.clickup.com/", 0xFFB26BFF));
        return l;
    }

    private SharedPreferences prefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }

    private void loadServices() {
        services.clear();
        try {
            String raw = prefs().getString(KEY_SERVICES, null);
            if (raw != null) {
                JSONArray a = new JSONArray(raw);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    services.add(new Service(o.getString("n"), o.getString("u"), o.getInt("c")));
                }
            }
        } catch (Exception ignored) { services.clear(); }
        if (services.isEmpty()) services.addAll(defaults());
    }

    private void saveServices() {
        JSONArray a = new JSONArray();
        try {
            for (Service s : services) a.put(new JSONObject().put("n", s.name).put("u", s.url).put("c", s.color));
        } catch (Exception ignored) { }
        prefs().edit().putString(KEY_SERVICES, a.toString()).apply();
    }

    // ---------------------------------------------------------------- utils

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private void toast(String t) { Toast.makeText(this, t, Toast.LENGTH_SHORT).show(); }
}
